package hw1;

public class ExitMachine
{
 

}
