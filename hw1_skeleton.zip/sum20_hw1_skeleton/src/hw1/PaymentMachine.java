package hw1;

public class PaymentMachine
{
  
	
}
