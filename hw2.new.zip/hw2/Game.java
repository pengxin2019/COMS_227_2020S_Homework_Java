package hw2;

import java.util.ArrayList;

/**
 * This Game class has methods and constructors creating a hangman game using the 
 * given word as the secret word and the default or chose
 * maximum number of wrong guesses.
 * @author Pengxin Yang
 *
 */
public class Game
{
	/**
	 * the secret word.
	 */
	private String secrectWord;
	/**
	 * the num of wrong guesses.
	 */
	private int numWrongGuess;
	/**
	 * if won
	 */
	private boolean isWon;
	/**
	 * the guessed letter.
	 */
	private java.lang.String guessedLetter;
	/**
	 * the displayed word.
	 */
	private HideableChar[] displayedWord;
	/**
	 * if the character is hidden.
	 */
	private boolean isHidden;
	/**
	 * the max of wrong guesses.
	 */
	private int maxWrongGuesses;
	/**
	 * public constant representing the maximum num of wrong guesses
	 * 
	 */
	public static final int DEFAULT_MAX_WRONG_GUESSES = 7;
	/**
	 * 
	 * There is one constructor, which is declared public 
	 * Constructs a hangman game using the given word as the secret word and the given value as the maximum number of wrong guesses.
	 * 
	 */
	public Game(java.lang.String word, int maxGuesses)
	{
		secrectWord = word;
		maxWrongGuesses = maxGuesses;
	}
	/**
	 * 
	 * There is one constructor, which is declared public 
	 * Constructs a hangman game using the given word as the secret word and the default maximum number of wrong guesses.
	 */
	public Game(java.lang.String word)
	{
		secrectWord = word;		
	}
	/**
	 * return Returns if the game is over
	 * @return
	 *    true if the game is over, otherwise false
	 */
	public boolean gameOver()
	{
		if (isWon || DEFAULT_MAX_WRONG_GUESSES == numWrongGuess)
		{
			return true;
			
		}
		else
		{
			return false;
		}
		
	}
	/**
	 * Returns a sequence of HideableChar representing the secret word or phrase. 
	 * @return
	 *    displayed form of the secret word
	 */
	public  HideableChar[] getDisplayedWord()
	{
		HideableChar [] arraySecrectWord = new HideableChar[secrectWord.length()];
		for (int i = 0; i < secrectWord.length(); i++)
		{
			arraySecrectWord[i] = new HideableChar(secrectWord.charAt(i));

		}
		return arraySecrectWord;
		
	}
	/**
	 * 	Returns the maximum number of wrong guesses for this game.
	 * @return
	 *    maximum number of wrong guesses
	 */
	public int getMaxGuesses()
	{
		return DEFAULT_MAX_WRONG_GUESSES;
	}
	/**
	 * 	Returns the complete secret word or phrase as a string.
	 * @return
	 *    secret word as a string
	 */
	public java.lang.String getSecretWord()	{
		return secrectWord;
	}
	/**
	 * 	Returns true if the letter has not been guessed already and occurs in the secret word, false otherwise
	 * @return
	 *    true if the letter has not been guessed
	 */
	
	public boolean guessLetter(char ch)
	{
//		If the game is already over, this method does nothing and returns false.
		if (gameOver())
		{
			return false;
		}
//		If the letter has previously been guessed by the player, records it as a wrong guess and returns false.
		if (guessedLetter.contains(Character.toString(ch)))
		{
			numWrongGuess += 1;
			return false;
		}
//		If the letter has not previously been guessed, but does not occur in the secret word or phrase, records it as a wrong guess and returns false.
		if (!guessedLetter.contains(Character.toString(ch)) && !secrectWord.contains(Character.toString(ch)))
		{
			numWrongGuess += 1;
			return false;
		}
//		If the letter has not previously been guessed and does occur in the secret word, changes all occurrences of the letter in the secret word to "not hidden" and returns true.
		if (!guessedLetter.contains(Character.toString(ch)) && secrectWord.contains(Character.toString(ch)))
		{
			for (int i = 0; i < secrectWord.length(); i++)
			{
				getDisplayedWord()[secrectWord.indexOf(ch)].unHide();
			}
			
			return true;
		}
		return false;

	}
	/**
	 * 	Returns a string containing all the letters guessed so far by the player, without duplicates.
	 * @return
	 *    letters guessed so far by the player
	 */
	public java.lang.String lettersGuessed()	
	{
		return guessedLetter;
	}
	/**
	 * 	Returns the number of wrong guesses made so far by the player.
	 * @return
	 *    number of wrong guesses
	 */
	public int numWrongGuesses()
	{
		return numWrongGuess;
	}
	/**
	 * 	Determines whether the player has guessed all the letters in the secret word.
	 * @return
	 *    true if the player has won, false otherwise
	 */
	public  boolean won()
	{
		return isWon;
	}


}
