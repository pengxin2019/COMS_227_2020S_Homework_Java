package hw2;
/**
 * Class representing a hidden character for a word-guessing game. 
 * Each instance encapsulates one character, 
 * which may have a status of "hidden" or "not hidden". 
 * When in the hidden state, getDisplayedChar returns null; 
 * if not hidden, getDisplayedChar returns the encapsulated character as a one-character string.
 * @author Pengxin Yang
 *
 */
public class HideableChar
{
	/**
	 * a boolean representing if a character is hidden.
	 */
	private boolean isHidden;
	/**
	 * the character.
	 */
	private char ch;
	
	/**
	 * Constructs a HideableChar with the given character as data. 
	 * If the given character is alphabetic (according to the method Character.isAlphabetic), 
	 * then this object is initially in the hidden state; otherwise, 
	 * it is initially not hidden.
	 * @param
	 *   ch - character data for this object
	 */
	public HideableChar(char ch)
	{
		this.ch = ch;
		if (Character.isAlphabetic(ch))
		{
			isHidden = true;
		}
		else
		{
			isHidden = false;
		}
	}
	/**
	 * Determines whether this object is currently in the hidden state.
	 * @return
	 *    true if this object is hidden, false otherwise
	 */
	public boolean isHidden()	
	{
		if (isHidden)
		{
			return true;
		}
		else 
		{
			return false;
		}
		
	}
	/**
	 * Sets this object's state to hidden.
	 * 
	 */
	public void hide()
	{
		isHidden = true;
		
	}
	/**
	 * Sets this object's state to not hidden.
	 */
	public void unHide()
	 {
		isHidden = false;
	 }
	/**
	 * Determines whether this object is currently in the hidden state.
	 * @return
	 *    true if this object is hidden, false otherwise
	 */
	public boolean matches(char ch)
	{
		if (this.ch == ch)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	/**
	 * Determines whether the given character is equal to the character stored in this object.
	 * @param
	 *  ch - given character to check
	 * @return
	 *    true if the given character is equal to this object's data
	 */
	public java.lang.String getDisplayedChar()
	{
		if (isHidden)
		{
			return null;
		}
		else
		{
			return Character.toString(this.ch);
		}
		
	}
	/**
	 * Returns a one-character string consisting of the character stored in this object. 
	 * (whether hidden or not).
	 * @return
	 *    string consisting of this object's character
	 */
	public java.lang.String getHiddenChar()
	{
		return Character.toString(this.ch);
		
	}
	
	
	
	
	
	

 
}
