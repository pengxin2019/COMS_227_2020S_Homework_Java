package hw2;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * this is the JUnit test for the class HideableChar.
 * @author Pengxin
 *
 */
public class HideableCharTest
{
	/**
	 * the character
	 */
	private char ch = 'a';
	/**
	 * the correct string we should get if we return the hidden character of a
	 */
	private String s = "a";
	/**
	 * the character to compare to the other character a
	 */
	private char ch2 = 'b';
	/**
	 * an HideableChar object with the given character
	 */
	private HideableChar hideableChar = new HideableChar(ch);
	/**
	 * test for the isHidden()method
	 * expected result is true
	 */
	@Test
	private void testIsHidden()
	{
		assertEquals(true, hideableChar.isHidden());

	}
	/**
	 * test for the hide() method
	 * expected result if true
	 */
	@Test
	private void testHide()
	{
		hideableChar.hide();
		assertEquals(true, hideableChar.isHidden());

	}
	/**
	 * test for the unhide()method
	 * expected result is false
	 */
	@Test
	private void testUnhide()
	{
		hideableChar.unHide();
		assertEquals(false, hideableChar.isHidden());
	}
	/**
	 * test for the matches()method
	 * expected result is false
	 */
	@Test
	private void testMatches​()
	{
		assertEquals(false, hideableChar.matches(ch2));
	}
	/**
	 * test for getDisplayedChar method
	 * expected result is the String s
	 */
	private void testGetDisplayedChar()
	{
		hideableChar.unHide();
		assertEquals(s, hideableChar.getDisplayedChar());	
		
	}
	/**
	 * test for the getHiddenChar method
	 * expected result is the String s
	 */
	@Test
	private void testGetHiddenChar()
	{
		hideableChar.unHide();
		assertEquals(s, hideableChar.getHiddenChar());	
		hideableChar.hide();
		assertEquals(s, hideableChar.getHiddenChar());	
	}

}
