package hw2;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * Generator for secret words or phrases for word-guessing games. 
 * A PhraseSelector chooses a line randomly from a file specified in the constructor. 
 * This version reads the file just once in the constructor and stores the words in an ArrayList
 * @author Pengxin Yang
 *
 */
public class PhraseSelector 
{
	/**
	 * the total number of lines in the file.
	 */
	private int numTotalLines = 0;
	/**
	 * create an Arraylist to contain all of the lines in this file.
	 */
	private ArrayList <String> arrAllLines = new <String> ArrayList();
	/**
	 * Constructs a PhraseSelector that will select words from the given file.
	 *  This constructor may throw a FileNotFoundException if the file cannot be opened.
	 */

	public PhraseSelector(java.lang.String givenFilename) throws java.io.FileNotFoundException

	{
		File file =new File(givenFilename);
		Scanner sc = new Scanner(file);

		while (sc.hasNextLine())
		{
			numTotalLines += 1;
			arrAllLines.add(sc.nextLine());
		}
		
	}
	/**
	 * Returns a word or phrase selected at random from this PhraseSelector's file, 
	 * using the given source of randomness. 
	 * @param
	 * rand - Random object
	 * @return
	 * a randomly selected line of the file
	 * @throws
	 * java.io.FileNotFoundException
	 */
	public java.lang.String selectWord(java.util.Random rand) throws java.io.FileNotFoundException
	{
		int randomNum = rand.nextInt(arrAllLines.size());
		return arrAllLines.get(randomNum);
	}
 
}
