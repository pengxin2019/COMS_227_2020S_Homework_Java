package hw2;

public class HideableChar
{

 
}
