package hw3;
import api.Cell;
import api.Piece;
import api.Position;
import api.Icon;

/**
 * A partial implementation of the Piece interface for Tetris-like falling shape games.
 * an abstrct class for 5 subclasses
 * @author Pengxin Yang
 */

public abstract class AbstractPiece implements Piece
{
	/**
	 * the position of this piece 
	 */
	private Position position;
	/**
	 * an array of cells
	 */
	private Cell[] cells;

	/**
	 * constructor of AbstractPiece
	 * @param position
	 */
	protected AbstractPiece(Position position)
	{
		this.position= position; 

	}
	/**
	 * Returns the position of this piece (upper-left corner of its bounding box).
	 * 
	 * @return position of this shape
	 */
	
	public Position getPosition()
	{
		return position;
	}
	/**
	 * Returns a deep copy of the Cell objects in this piece. The cell positions are relative to the upper-left corner of its bounding box.
	 * 
	 * @return copy of the cells in this piece
	 */
	public Cell[] getCells() {
		Cell[] copy = new Cell[cells.length];
		for (int i = 0; i < cells.length; i++)
		{
			copy[i]=new Cell(cells[i]);
		}
		return copy;
	}
	/**
	 * Returns a new array of Cell objects representing the icons in this piece with their absolute positions (relative positions plus position of bounding box).
	 * 
	 * @return copy of the cells in this piece, with absolute positions
	 */
	public Cell[] getCellsAbsolute() {
		Cell[] ret = new Cell[cells.length];
		for (int i = 0; i< cells.length; i++)
		{
			int row = cells[i].getRow() + position.row();
			int col = cells[i].getCol() + position.col();
			Icon b = cells[i].getIcon();
			ret[i] = new Cell(b, new Position(row, col));
		}
		
		return ret;
	}
	/**
	 * Sets the cells in this piece, making a deep copy of the given array.
	 * 
	 * @param givenCells new cells for this piece
	 */
	public void setCells(Cell[] givenCells) {
		cells = new Cell[givenCells.length];
		
		for (int i = 0; i < givenCells.length; i++)
		{
			cells[i] = new Cell(givenCells[i]);
		}
	}
	/**
	 * Shifts the position of this piece down (increasing the row) by one. No bounds checking is done.
	 */
	public void shiftDown() {
		position = new Position(position.row() + 1, position.col());
	}
	/**
	 * Shifts the position of this piece left (decreasing the column) by one. No bounds checking is done.
	 */
	
	public void shiftLeft() {
		position = new Position(position.row(), position.col()-1);
	}
	/**
	 * Shifts the position of this piece right (increasing the column) by one. No bounds checking is done.
	 */
	
	public void shiftRight() {
		position = new Position(position.row(), position.col()+1);
	}
	/**
	 * Transforms this piece without altering its position according to the rules of the game to be implemented. Typical operations would be rotation or reflection. No bounds checking is done.
	 */
	public void transform() {
		// TODO Auto-generated method stub
	}
	/**
	 * Cycles the icons within the cells of this piece. Each icon is shifted forward to the next cell (in the original ordering of the cells). The last icon wraps around to the first cell.
	 */
	public void cycle() {
		Icon tempIcon = cells[cells.length - 1].getIcon();

		for (int i = cells.length - 1; i > 0; i--)
		{
			cells[i].setIcon(cells[i - 1].getIcon());

		}
		
		cells[0].setIcon(tempIcon);
	}
	/**
	 * Returns a deep copy of this object having the correct runtime type.
	 * 
	 * @return a deep copy of this object
	 */
	public Piece clone()
	{
		try
		{
			// call the Object clone() method to create a shallow copy
			AbstractPiece s = (AbstractPiece) super.clone();

			// then make it into a deep copy (note there is no need to copy the position,
			// since Position is immutable, but we have to deep-copy the cell array
			// by making new Cell objects
			s.cells = new Cell[cells.length];
			for (int i = 0; i < cells.length; ++i)
			{
				s.cells[i] = new Cell(cells[i]);
			}
			return s;
		}
		catch (CloneNotSupportedException e)
		{
			// can't happen, since we know the superclass is cloneable
			return null;
		}
	}
}

