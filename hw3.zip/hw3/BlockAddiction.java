package hw3;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import api.AbstractGame;
import api.Generator;
import api.Icon;
import api.Position;

/**
 * a subclass of AbstractGame
 * implementations of the method determinePositionsToCollapse() which finds the positions in collapsible sets 
 * two constructors are provided
 * @author Pengxin
 */

public class BlockAddiction extends AbstractGame{
	/**
	 * a int instance variable represent the number of rows that have been filled to initialize the game
	 */
	private int preFillRows;
	/**
	 * a BasicGenerator which can produce icon randomly
	 */
	
	private BasicGenerator iconGenerator = new BasicGenerator(new Random());
	/**
	 * a constructor of BlockAddiction
	 * If preFillRows is greater than zero, your constructor should initialize the bottom preFillRows rows in a checkerboard pattern, 
	 * using random icons obtained from the generator. 
	 * The checkerboard pattern should place an icon at (row, col) in the grid if both row and col are even, 
	 * or if both row and col are odd. 
	 * @param height
	 * @param width
	 * @param gen
	 * @param preFillRows
	 */

	public BlockAddiction(int height, int width, Generator gen, int preFillRows)
	{
		
		super(height, width, gen);
		this.preFillRows = preFillRows;
		if(preFillRows > 0)
		{
			int startRow = Math.max(0, getHeight() - preFillRows);
			for (int i = 0; i < getWidth(); i++)//col
			{
				for (int k = startRow ; k < getHeight(); k++)//row
				{
					if (k%2 == i%2 )
					{
						setBlock(k, i, gen.randomIcon());
					}
				}
			}		
			
		}
	}
	/**
	 * a constructor of BlockAddiction
	 * @param height
	 * @param width
	 * @param gen
	 */
	public BlockAddiction(int height, int width, Generator gen)
	{
		super(height, width, gen);
	}
	/**
	 * Examines the grid and returns a list of positions to be collapsed.
	 * In BlockAddiction, the task of determinePositionsToCollapse() is to identify the positions of icons in all "collapsible sets",
	 *  that is, sets of three or more adjacent icons with matching color.
	 * @return  a non-duplication sorted list of positions to collapse
	 */

	@Override
	public java.util.List<Position> determinePositionsToCollapse() {
		List<Position> tempPositionsToCollapse = null;
		List<Position> positionsToCollapse = null;

		
		for (int k = 0; k < getHeight() - preFillRows; k++)//row
		{
			for (int i = 0; i < getWidth() - 1; i++)//col
			{
				Icon a = getIcon(k, i);//
				Icon b = getIcon(k + 1, i);//bottom cell
				Icon e = getIcon(k, i + 1);//right cell
				
				Position center = new Position(k, i);
				Position bottom = new Position(k + 1, i);
				Position left = new Position(k, i - 1);
				Position up = new Position(k - 1, i);
				Position right = new Position(k, i + 1);

				
				if (k == 0 && i == 0)//the center position is up left corner
				{
					if (!(a == null || b == null || e == null) && a. matches(b) && a. matches(e))
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(bottom);
						tempPositionsToCollapse.add(right);
					}
					
				}
				else if (k != 0 && i == 0)//the center position is left border
				{
					Icon d = getIcon(k - 1, i);//up
					
					if (!(a == null || b == null || e == null) && a. matches(b) && a. matches(e))//matches bottom and right
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(bottom);
						tempPositionsToCollapse.add(right);
					}
					else if (!(a == null || d == null || e == null) && a. matches(e) && a. matches(d))//matches right and up
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(right);
						tempPositionsToCollapse.add(up);
					}
					else if(!(a == null || b == null || d == null) && a. matches(b) && a. matches(d))//matches bottom and up
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(bottom);
						tempPositionsToCollapse.add(up);
					}
					
				}
				else if(k == 0 && i != 0)//the center position is up border
				{
					Icon c = getIcon(k, i - 1);//left
					
					if (!(a == null || b == null || e == null) && a. matches(b) && a. matches(e))//matches right and bottom
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(bottom);
						tempPositionsToCollapse.add(right);
					}
					else if (!(a == null || b == null || c == null) && a. matches(b) && a. matches(c))//matches bottom and left
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(bottom);
						tempPositionsToCollapse.add(left);
					}
					else if (!(a == null || c == null || e == null) && a. matches(e) && a. matches(c))//matches right and left
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(right);
						tempPositionsToCollapse.add(left);
					}
					
				}
				else if (k == 0 && i == getWidth() - 1)//the center position is right corner
				{
					Icon c = getIcon(k, i - 1);//left
					
					if (!(a == null || b == null || c == null) && a. matches(b) && a. matches(c))
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(bottom);
						tempPositionsToCollapse.add(left);
					}
				}
				else if(k != 0 && i == getWidth() - 1)//the center position is right border
				{
					Icon c = getIcon(k, i - 1);//left
					Icon d = getIcon(k - 1, i);//up
					
					if (!(a == null || b == null || e == null) && a. matches(b) && a. matches(e))//matches bottom and right
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(bottom);
						tempPositionsToCollapse.add(right);
					}
					else if (!(a == null || b == null || c == null) && a. matches(b) && a. matches(c))//matches bottom and left
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(bottom);
						tempPositionsToCollapse.add(left);
					}
					else if (!(a == null || d == null || b == null) && a. matches(b) && a. matches(d))//matches up and bottom
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(bottom);
						tempPositionsToCollapse.add(up);
					}
				}
				else// the center position is in the center(no corner no boarder) of game grid
				{
					Icon c = getIcon(k, i - 1);//left
					Icon d = getIcon(k - 1, i);//up
					
					if (!(a == null || b == null || e == null) && a. matches(b) && a. matches(e))//matches bottom and right
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(bottom);
						tempPositionsToCollapse.add(right);
					}
					else if (!(a == null || b == null || c == null) && a. matches(b) && a. matches(c))//matches bottom and left
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(bottom);
						tempPositionsToCollapse.add(left);
					}
					else if (!(a == null || d == null || e == null) && a. matches(d) && a. matches(e))//matches up and right
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(up);
						tempPositionsToCollapse.add(right);
					}
					else if (!(a == null || d == null || c == null) && a. matches(d) && a. matches(c))//matches up and left
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(up);
						tempPositionsToCollapse.add(left);
					}
					else if (!(a == null || d == null || b == null) && a. matches(d) && a. matches(b))//matches up and bottom
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(up);
						tempPositionsToCollapse.add(bottom);
					}
					else if (!(a == null || c == null || e == null) && a. matches(e) && a. matches(c))//matches right and left
					{
						tempPositionsToCollapse.add(center);
						tempPositionsToCollapse.add(right);
						tempPositionsToCollapse.add(left);
					}
					
				}
				
			}
		}
//	The tempPositionsToCollapse may contain many duplicates, which is not hard to deal with - just create a new list, 
//		copy the positions over, but ignore any that you have already found
		
		for (int i = 0; i < tempPositionsToCollapse.size(); i++)
		{
			while(!positionsToCollapse.contains(tempPositionsToCollapse.get(i)))
			{
				positionsToCollapse.add(tempPositionsToCollapse.get(i));
			}		
		}
		//the list needs to be sorted
		Collections.sort(positionsToCollapse);
		return positionsToCollapse;
	}
}
