package hw3;

import api.Cell;
import api.Icon;
import api.Position;

/**
 * Very simple subclass of AbstractPiece for experimentation.
 *@author Pengxin Yang
 */

public class CornerPiece extends AbstractPiece {
/**
 * an array of Position objects in the order you want
 */
	private static final Position[] sequence = 
		{
				new Position(0, 0), 
				new Position(0, 1), 
				new Position(1, 1), 
				new Position(1, 0), 
		};
	/**
	 * an array of int to represent the index of the positions in the final Position[] sequence
	 */
	private int[] count = {0, 1, 2, 3};
	/**
	 * an int to keep track of the count
	 */
	private int index;
	/**
	 * a constructor of CornerPiece
	 * @param givenPosition
	 * @param icons
	 * @throws
	 * a new IllegalArgumentException error if the length of the icon array is not 3
	 */
	public CornerPiece(Position givenPosition, Icon[] icons)
	{
		super(givenPosition);
		
		if(icons.length != 3) 
		{
			 throw new IllegalArgumentException("Must be passed an array with 3 icons.");
		}
		
		Cell[] cells = new Cell[3];
		//assign the initial position of the 3 cells in a CornerPiece
		
		cells[0] = new Cell(icons[0], new Position(0, 0));
		cells[1] = new Cell(icons[1], new Position(1, 0));
		cells[2] = new Cell(icons[2], new Position(1, 1));
		super.setCells(cells);
		index  = 0;
		
	}
	/**
	 * Transforms this piece without altering its position according to the rules of the game to be implemented.
	 *  Typical operations would be rotation or reflection. No bounds checking is done.
	 * 
	 */
	@Override
	public void transform() {
		Cell[] cells = getCells();
		Cell a = cells[0];
		Cell b = cells[1];
		Cell c = cells[2];
		
		index += 1;
		index = index%4;
		
		c.setRowCol(b.getRow(), b.getCol());//assign the position of b to c
		b.setRowCol(a.getRow(), a.getCol());//assign the position of a to b
		a.setRowCol(sequence[count[index]].row(), sequence[count[index]].col());

		super.setCells(cells);

	}

}
