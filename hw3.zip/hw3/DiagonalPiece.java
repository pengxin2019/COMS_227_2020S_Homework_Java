package hw3;

import api.Cell;
import api.Icon;
import api.Piece;
import api.Position;

/**
 * Very simple subclass of AbstractPiece for experimentation.
 *produce DiagonalPiece which contains 2 cellls
 *@author pengxin yang
 */
public class DiagonalPiece extends AbstractPiece 
{
	/**
	 * a constructor of the DiagonalPiece
	 * @param givenPosition
	 * @param icons
	 * @throws
	 * IllegalArgumentException if the length of the icon array is not 2
	 */
	 
	public DiagonalPiece(Position givenPosition, Icon[] icons)
	{
		super(givenPosition);
		
		if(icons.length != 2) 
		{
			 throw new IllegalArgumentException("Must be passed an array with 2 icons.");
		}
		
		Cell[] cells = new Cell[2];
		cells[0] = new Cell(icons[0], new Position(0, 0));
		cells[1] = new Cell(icons[1], new Position(1, 1));
		super.setCells(cells);

	}
	/**
	 * Transforms this piece without altering its position according to the rules of the game to be implemented. Typical operations would be rotation or reflection. No bounds checking is done.
	 */
	@Override
	public void transform() {
		Cell[] cells = getCells();
		
		cells[0].setCol(1-cells[0].getCol()); 
		cells[1].setCol(1-cells[1].getCol());
		super.setCells(cells);

	}


}
