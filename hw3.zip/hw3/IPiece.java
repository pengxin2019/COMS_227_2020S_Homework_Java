package hw3;

import api.Cell;
import api.Icon;
import api.Position;


/**
 * Very simple subclass of AbstractPiece for experimentation.
 *produce LPiece which contains 3 cells
 *@author Pengxin Yang
 */
public class IPiece extends AbstractPiece {
	/**
	 * a Cell array
	 */
	private Cell[] cells;
	/**
	 * a constructor of IPiece 
	 * @param givenPosition
	 * @param icons
	 * @throws
	 * a new IllegalArgumentException if the length of the icon array is not 3
	 */
	public IPiece(Position givenPosition, Icon[] icons) 
	{
		super(givenPosition);
		
		if(icons.length != 3) 
		{
			 throw new IllegalArgumentException("Must be passed an array with 3 icons.");
		}
		
		cells = new Cell[3];
		cells[0] = new Cell(icons[0], new Position(0, 1));
		cells[1] = new Cell(icons[1], new Position(1, 1));
		cells[2] = new Cell(icons[2], new Position(2, 1));
		super.setCells(cells);

	}
	

}
