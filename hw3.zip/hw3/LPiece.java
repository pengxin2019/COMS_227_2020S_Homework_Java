package hw3;

import api.Cell;
import api.Icon;
import api.Position;

/**
 * Very simple subclass of AbstractPiece for experimentation.
 *produce LPiece which contains 4 cells
 *@author Pengxin Yang
 */
public class LPiece extends AbstractPiece
{
	/**
	 * 
	 * @param givenPosition
	 * @param icons
	 * @throws a new IllegalArgumentException if the length of the icon array is not 3
	 */

	public LPiece(Position givenPosition, Icon[] icons)
	{
		super(givenPosition);
		
		if(icons.length != 4) 
		{
			 throw new IllegalArgumentException("Must be passed an array with 4 icons.");
		}
		
		Cell[] cells = new Cell[4];
		cells[0] = new Cell(icons[0], new Position(0, 0));
		cells[1] = new Cell(icons[1], new Position(0, 1));
		cells[2] = new Cell(icons[2], new Position(1, 1));
		cells[3] = new Cell(icons[3], new Position(2, 1));
		
		super.setCells(cells);
		
	}
	/**
	 * Transforms this piece without altering its position according to the rules of the game to be implemented. Typical operations would be rotation or reflection. No bounds checking is done.
	 */

	@Override
	public void transform() {
		Cell[] cells = getCells();
		cells[0].setCol(2-cells[0].getCol()); 
		super.setCells(cells);

	}
	

}
