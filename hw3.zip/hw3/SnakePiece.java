package hw3;

import api.Cell;
import api.Icon;
import api.Position;


/**
 * Very simple subclass of AbstractPiece for experimentation.
 *@author Pengxin Yang
 */

public class SnakePiece extends AbstractPiece 
{
	/**
	 * an array of position of the cell
	 */

	private static final Position[] sequence = 
		{
				new Position(0, 0), 
				new Position(0, 1), 
				new Position(0, 2), 
				new Position(1, 2), 
				new Position(1, 1), 
				new Position(1, 0), 
				new Position(2, 0), 
				new Position(2, 1), 
				new Position(2, 2), 
				new Position(1, 2), 
				new Position(1, 1),
				new Position(1, 0), 
		};
	/**
	 * an array of int to represent the index or locations of the first cell in Position[] sequence
	 */
	private int[] count = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
	/**
	 * Counter indicating number of transforming
	 */
	private int index;
	/**
	 * a constructor of SnakePiece
	 * @param givenPosition
	 * @param icons
	 */

	public SnakePiece(Position givenPosition, Icon[] icons)
	{
		super(givenPosition);
		
		if(icons.length != 4) 
		{
			 throw new IllegalArgumentException("Must be passed an array with 4 icons.");
		}
		
		Cell[]cells = new Cell[4];
		cells[0] = new Cell(icons[0], new Position(0, 0));
		cells[1] = new Cell(icons[1], new Position(1, 0));
		cells[2] = new Cell(icons[2], new Position(1, 1));
		cells[3] = new Cell(icons[2], new Position(1, 2));
		super.setCells(cells);
		
		index = 0;
	}
	
	/**
	 * Transforms this piece without altering its position according to the rules of the game to be implemented. Typical operations would be rotation or reflection. No bounds checking is done.
	 */
	
	@Override
	public void transform() {
		Cell[] cells = getCells();
		Cell a = cells[0];
		Cell b = cells[1];
		Cell c = cells[2];
		Cell d = cells[3];
		
		index += 1;
		index = index%12;
		
		d.setRowCol(c.getRow(), c.getCol());//assign the position of c to d
		c.setRowCol(b.getRow(), b.getCol());//assign the position of b to c
		b.setRowCol(a.getRow(), a.getCol());//assign the position of a to b
		a.setRowCol(sequence[count[index]].row(), sequence[count[index]].col());
		
		super.setCells(cells);

		
	}
}
